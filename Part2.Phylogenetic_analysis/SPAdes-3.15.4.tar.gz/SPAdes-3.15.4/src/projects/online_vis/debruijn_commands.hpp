//***************************************************************************
//* Copyright (c) 2015 Saint Petersburg State University
//* Copyright (c) 2011-2014 Saint Petersburg Academic University
//* All Rights Reserved
//* See file LICENSE for details.
//***************************************************************************

#pragma once

#include "drawing_commands.hpp"
#include "setting_commands.hpp"
#include "position_commands.hpp"
#include "statistics_commands.hpp"
#include "processing_commands.hpp"
