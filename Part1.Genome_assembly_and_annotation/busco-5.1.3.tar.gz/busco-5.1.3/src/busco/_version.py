#!/usr/bin/env python3
# coding: utf-8
"""

Copyright (c) 2016-2021, Evgeny Zdobnov (ez@ezlab.org)
Licensed under the MIT license. See LICENSE.md file.

"""
__version__ = "5.1.3"
